-- Step 1: Create the database (if it doesn't exist)
CREATE DATABASE EmployeeDB;

-- Step 2: Select the database to use
USE EmployeeDB;

-- Step 3: Create the Employees table
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Department VARCHAR(50),
    HireDate DATE,
    Salary INT
);

-- Step 4: Insert sample data into the Employees table
INSERT INTO Employees (EmployeeID, FirstName, LastName, Department, HireDate, Salary) VALUES
(1, 'John', 'Doe', 'HR', '2015-03-15', 55000),
(2, 'Jane', 'Smith', 'IT', '2018-07-10', 75000),
(3, 'Jim', 'Brown', 'Marketing', '2020-06-01', 60000),
(4, 'Alice', 'White', 'IT', '2017-09-23', 70000),
(5, 'Bob', 'Johnson', 'Sales', '2019-02-14', 65000),
(6, 'Charlie', 'Lee', 'HR', '2021-01-05', 58000);
